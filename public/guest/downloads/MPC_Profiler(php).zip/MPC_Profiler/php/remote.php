<?php
namespace MPCProfiler;
class Measure {
	
	// params
	private $apiKey;
	private $projectID;
	private $measureName;
	private $sendEveryPoint;
	
	// local params
	private $path;
	private $arrayMode;
	private $showPlace;
	private $showVarType;
	private $showVarMemUsage;
	private $cleanLogFile;
	
	// service vars
	private $type;
	private $output;
	private $sessionId;
	private $newLine;
	private $timePrecision;
	private $logFileIsCleaned;
	private $baseMemUsageValue;
	private $lastMemUsageValue;
	private $memUsageIndex;
	private $baseTimeUsageValue;
	private $lastTimeUsageValue;
	private $timeUsageIndex;
	private $dumpIndex;
	private $classDestination;
	private $templates;
	private $errors = Array(
		'invalid_params' => 'Incorrect parameter type passed to constructor',
		'invalid_precision' => 'Time rounding precision must be positive number',
		'no_log' => 'Log file \'{logPath}\' does not exist',
		'dump_object_invalid_param' => 'dumpObject() accepts only variable with type \'object\' or \'array\'',
		'no_template' => 'Template \'{templatePath}\' file was not found',
		'no_js' => 'Javascript file was not found',
		'no_css' => 'Css file was not found',
	);
	
	const API_SERVER_URI = 'http://ec2-18-191-88-140.us-east-2.compute.amazonaws.com';
	
	public function __construct(
		$apiKey,
		$projectID,
		$measureName,
		$sendEveryPoint = false
	) {
		// default params which defined as constructor arguments in local.php class
		$path = false;
		$arrayMode = 1;
		$showPlace = true;
		$showVarType = true;
		$showVarMemUsage = true;
		$cleanLogFile = true;
		$timePrecision = 4;
		
		if(!is_string($apiKey)|| !strlen($apiKey) || !intval($projectID) || !is_string($measureName)|| !strlen($measureName)) {
			$this->throwError('invalid_params');
		}
		
		$this->newLine = '<br>';
		$this->type = 'html';
		
		if(!!$path) {
			if (!file_exists($path)) {
				$this->throwError('no_log', Array('logPath' => $path));
			}
			
			$this->path = $path;
			
			$pathInfo = pathinfo($path);
			if(!in_array($pathInfo['extension'], Array('php', 'htm', 'html'))) {
				$this->newLine =  "\n";
				$this->type = 'text';
			}
		}
		
		$this->apiKey = $apiKey;
		$this->projectID = $projectID;
		$this->measureName = $measureName;
		$this->sendEveryPoint = $sendEveryPoint;
		$this->arrayMode = $arrayMode;
		$this->showPlace = $showPlace;
		$this->showVarType = $showVarType;
		$this->showVarMemUsage = $showVarMemUsage;
		$this->cleanLogFile = $cleanLogFile;
		$this->timePrecision = $timePrecision;
		
		$this->logFileIsCleaned = false;
		
		$this->dumpIndex = -1;
		
		// making session ID
		$this->sessionId = md5(date('ymdhis').rand()*rand());
	}
	
	public function exceptionHandler($exception) {
		echo 'MPCProfiler Fatal Error: ', $exception->getMessage(), "\n";
	}
	
	private function throwError($errorCode, $data = false) {
	
		@set_exception_handler(array($this, 'exceptionHandler'));
		
		if(!strlen($errorCode)) {
			throw new \Exception('No error code was passed to throwError() function');
		}
		
		$errorMessage = $this->errors[$errorCode];
		if(!strlen($errorMessage)) {
			throw new \Exception('Error with code '.$errorCode.' does not exists');
		}
		
		if(is_array($data) && count($data)) {
			$placeholders = array_map(
				function($varName){ return '{'.$varName.'}'; },
				array_keys($data)
			);
			$errorMessage = str_replace($placeholders, array_values($data), $errorMessage);
		}
		
		throw new \Exception($errorMessage);
	}
	
	private function getClassDestination() {
		if(!$this->classDestination) {
			$reflector = new \ReflectionClass(get_called_class());
			$this->classDestination = preg_replace('/[^\/]*$/', '', $reflector->getFileName());
		}
		
		return $this->classDestination;
	}
	
	private function output($data, $send=false) {
		
		if(!$this->sendEveryPoint) {
			if(!is_array($this->output)) {
				$this->output = Array(
					'api_key' => $this->apiKey,
					'project_id' => $this->projectID,
					'session_id' => $this->sessionId,
					'measure_name' => $this->measureName,
					'points' => Array();
				);
			}
			$this->output['points'][] = $data;
			
			if(!$send)
				return true;
			
			$apiPath = '/point/add_items/';
			
		} else {
			$data = array_merge(Array(
					'api_key' => $this->apiKey,
					'project_id' => $this->projectID,
					'session_id' => $this->sessionId,
					'measure_name' => $this->measureName,
			), $data);
			$apiPath = '/point/add_item/';
		}
		$opts = array(
			CURLOPT_URL => self::API_SERVER_URI.'/api'.$apiPath, 
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $data,
			CURLOPT_RETURNTRANSFER => 1
		);
		$ch = curl_init();
		curl_setopt_array($ch, $opts);
		$output = curl_exec($ch); 
		curl_close($ch); 
		// TODO get response and add errors logging
	}
	
	private function getTraceIfNeeded() {
		if($this->showPlace) {
			$trace = debug_backtrace(false);
			return json_encode($trace);
		} else {
			return '';
		}
	}
	
	private function prepareArray($array){
		
		$output = gettype($array).' ('.count($array).')';

		foreach($array as $key => $item) {
			$isTree = false;
			if(is_array($item) || is_object($item)) {
				$isTree = true;
				$item = $this->prepareArray($item);
			}

			$valueType = '';
			$valueMemUsage = '';
			$keyClass = ($isTree) ? 'key' : 'static-key';
			if(!$isTree) {
				
				if($this->showVarType) {
					$valueType = gettype($item);
				}

				if($this->showVarMemUsage) {
					$valueMemUsage = ' '.(strlen($item)*8).$unit;
				}
			}
			$extraInfo = $valueType.$valueMemUsage;
			$output .= $this->getProcessTemplate('array_item', Array(
				'arrayMode' => $this->arrayMode,
				'valueType' => $valueType == 'string' && strlen($item) > 200 ? 2 : 1,
				'keyClass' => $keyClass,
				'key' => $key,
				'item' => $item,
				'extraInfo' => $extraInfo,
			));
		}

		return $output;
	}
	
	private function dumpObject($object) {
	
		if(!is_object($object) && !is_array($object)) {
			$this->throwError('dump_object_invalid_param');
		}
		
		ob_start();
		var_dump($object);
		$object = ob_get_contents();
		ob_end_clean();
		
		if($this->type == 'html') {
			$object = $this->getProcessTemplate('object', Array('object' => $object));
		}
		
		return $object;
	}
	
	private function includeMediaIfNeeded(&$styles, &$scripts) {
		if(!defined("PHP_TELLER_MEDIA_INCLUDED")) {
			$scriptsFile = $this->getClassDestination().'/scripts/script.min.js';
			if (!file_exists($scriptsFile)) {
				$this->throwError('no_js');
			}
			$stylesFile = $this->getClassDestination().'/styles/style.min.css';
			if (!file_exists($stylesFile)) {
				$this->throwError('no_css');
			}
			$styles = $this->getProcessTemplate('styles', Array(
				'styles' => file_get_contents($stylesFile)
			), false);
			$scripts = $this->getProcessTemplate('scripts', Array(
				'scripts' => file_get_contents($scriptsFile),
			), false);
			define("PHP_TELLER_MEDIA_INCLUDED", true);
		}
	}
	
	private function getProcessTemplate($templateName, $data, $removeEmpty = true) {

		$templatePath = $this->getClassDestination().'/templates/'.$templateName.'.tpl';
		
		if (!file_exists($templatePath)) {
			$this->throwError('no_template', Array('templatePath' => $templatePath));
		}
		
		$template = file_get_contents($templatePath);

		if(is_array($data) && count($data)) {
			$replaces = Array();
			foreach($data as $varName => $value) {
				$placeholder = '{'.$varName.'}';
				
				$replaces[$placeholder] = $value;
				
				if(!strlen($value) && $removeEmpty) {
					$template = preg_replace('/\(\(.*'.$placeholder.'.*\)\)/', '', $template);
				}
			}
			if(count($replaces)) {
				$template = str_replace(array_keys($replaces), array_values($replaces), $template);
			}
		}
		
		if($removeEmpty)
			$template = str_replace(Array('((', '))'), '', $template);
		
		return $template;
	}
   
	public function memUsage($comment = '', $send=false) {
		
		$traceInfo = $this->getTraceIfNeeded();

		if(!strlen($comment))
			$comment = '';
			
		$time = date('Y-m-d H:i:s');
		
		if(!$this->baseMemUsageValue) {
			$this->baseMemUsageValue = memory_get_usage();
			$this->lastMemUsageValue = 0;
			$newMemUsageValue = 0;
			$memUsageDiff = 0;
		} else {
			$this->memUsageIndex = intval($this->memUsageIndex) + 1;
			$newMemUsageValue = memory_get_usage() - $this->baseMemUsageValue;
			$memUsageDiff = $newMemUsageValue-$this->lastMemUsageValue;
			if($memUsageDiff > 0)
				$memUsageDiff = '+'.$memUsageDiff;
			$this->lastMemUsageValue = $newMemUsageValue;
		}

		$this->output(Array(
			"type" => 1,
			"index" => intval($this->memUsageIndex),
			"value" => $newMemUsageValue,
			"diff" => $memUsageDiff,
			"trace" => $traceInfo,
			"comment" => $comment,
			"datetime" => $time
		), $send);
	}
	
	public function timeUsage($comment = '', $send=false) {
		
		$traceInfo = $this->getTraceIfNeeded();
		
		if(!strlen($comment))
			$comment = '';
			
		$time = date('Y-m-d H:i:s');
			
		if(!$this->baseTimeUsageValue) {
			$this->baseTimeUsageValue = microtime(true);
			$this->lastTimeUsageValue = 0;
			$newTimeUsageValue = 0;
			$timeUsageDiff = 0;
		} else {
			$this->timeUsageIndex = intval($this->timeUsageIndex) + 1;
			$newTimeUsageValue = microtime(true) - $this->baseTimeUsageValue;
			$timeUsageDiff = $newTimeUsageValue-$this->lastTimeUsageValue;
			if($timeUsageDiff > 0)
				$timeUsageDiff = '+'.number_format($timeUsageDiff, $this->timePrecision);
			$output = '(time) #'.$this->timeUsageIndex.$time.$traceInfo.': '.number_format($newTimeUsageValue, $this->timePrecision).$unit.' ('.$timeUsageDiff.$unit.')'.$comment.$this->newLine;
			$this->lastTimeUsageValue = $newTimeUsageValue;
		}
		
		$this->output(Array(
			"type" => 2,
			"index" => intval($this->timeUsageIndex),
			"value" => number_format($newTimeUsageValue, $this->timePrecision),
			"diff" => $timeUsageDiff,
			"trace" => $traceInfo,
			"comment" => $comment,
			"datetime" => $time
		), $send);
	}
	
	public function log() {
	
		$styles = $scripts = '';
		
		$traceInfo = $this->getTraceIfNeeded();
		
		$time = date('Y-m-d H:i:s');
		
		$this->dumpIndex = intval($this->dumpIndex) + 1;
		
		$output = '(log) #'.$this->dumpIndex.$time.$traceInfo.': ';
		
		$dumpItems = func_get_args();
		$itemsCount = count($dumpItems);
		
		foreach($dumpItems as $key => $item) {
			$noSeparator = false;
			if(is_array($item) || is_object($item)) {
				$noSeparator = true;
				if($this->type == 'html') {
					$this->includeMediaIfNeeded($styles, $scripts);

					$item = $this->prepareArray($item);
					$item = $this->getProcessTemplate('container', Array('item' => $item));
				} else {
					$item = $this->dumpObject($item);
				}
			} 
			
			$separator = !$noSeparator && $key+1 < $itemsCount ? ' | ' : '';
			
			$output .= $item.$separator;
		}
		
		$this->output($styles.$output.$this->newLine.$scripts);
		
	}
}
?>