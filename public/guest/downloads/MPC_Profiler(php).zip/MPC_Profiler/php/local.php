<?php
class MPCProfiler {
	
	// params
	private $path;
	private $arrayMode;
	private $showUnit;
	private $showTime;
	private $showPlace;
	private $showVarType;
	private $showVarMemUsage;
	private $cleanLogFile;
	
	// service vars
	private $type;
	private $newLine;
	private $timePrecision;
	private $logFileIsCleaned;
	private $baseMemUsageValue;
	private $lastMemUsageValue;
	private $memUsageIndex;
	private $baseTimeUsageValue;
	private $lastTimeUsageValue;
	private $timeUsageIndex;
	private $dumpIndex;
	private $classDestination;
	private $templates;
	private $errors = Array(
		'invalid_params' => 'Incorrect parameter type passed to constructor',
		'invalid_precision' => 'Time rounding precision must be positive number',
		'no_log' => 'Log file \'{logPath}\' does not exist',
		'dump_object_invalid_param' => 'dumpObject() accepts only variable with type \'object\' or \'array\'',
		'no_template' => 'Template \'{templatePath}\' file was not found',
		'no_js' => 'Javascript file was not found',
		'no_css' => 'Css file was not found',
	);
	
	
	public function __construct(
		$path = false,
		$arrayMode = 1,
		$showUnit = true,
		$showTime = true,
		$showPlace = true,
		$showVarType = true,
		$showVarMemUsage = true,
		$cleanLogFile = true,
		$timePrecision = 4
	) {

		if((!!$path && !is_string($path)) || !is_bool($showUnit) || !is_bool($showVarType) || !is_bool($showVarMemUsage) ||
				!is_bool($showTime) || !is_bool($showPlace) || !is_bool($cleanLogFile) || !is_int($timePrecision) || !in_array($arrayMode, Array(1,2))) {
			$this->throwError('invalid_params');
		}
		
		if($timePrecision < 0) {
			$this->throwError('invalid_precision');
		}
		
		$this->newLine = '<br>';
		$this->type = 'html';
		
		if(!!$path) {
			if (!file_exists($path)) {
				$this->throwError('no_log', Array('logPath' => $path));
			}
			
			$this->path = $path;
			
			$pathInfo = pathinfo($path);
			if(!in_array($pathInfo['extension'], Array('php', 'htm', 'html'))) {
				$this->newLine =  "\n";
				$this->type = 'text';
			}
		}
		
		$this->arrayMode = $arrayMode;
		$this->showUnit = $showUnit;
		$this->showTime = $showTime;
		$this->showPlace = $showPlace;
		$this->showVarType = $showVarType;
		$this->showVarMemUsage = $showVarMemUsage;
		$this->cleanLogFile = $cleanLogFile;
		$this->timePrecision = $timePrecision;
		
		$this->logFileIsCleaned = false;
		
		$this->dumpIndex = -1;
	}
	
	public function exceptionHandler($exception) {
		echo 'MPCProfiler Fatal Error: ', $exception->getMessage(), "\n";
	}
	
	private function throwError($errorCode, $data = false) {
	
		@set_exception_handler(array($this, 'exceptionHandler'));
		
		if(!strlen($errorCode)) {
			throw new Exception('No error code was passed to throwError() function');
		}
		
		$errorMessage = $this->errors[$errorCode];
		if(!strlen($errorMessage)) {
			throw new Exception('Error with code '.$errorCode.' does not exists');
		}
		
		if(is_array($data) && count($data)) {
			$placeholders = array_map(
				function($varName){ return '{'.$varName.'}'; },
				array_keys($data)
			);
			$errorMessage = str_replace($placeholders, array_values($data), $errorMessage);
		}
		
		throw new Exception($errorMessage);
	}
	
	private function getClassDestination() {
		if(!$this->classDestination) {
			$reflector = new ReflectionClass(get_called_class());
			$this->classDestination = preg_replace('/[^\/]*$/', '', $reflector->getFileName());
		}
		
		return $this->classDestination;
	}
	
	private function output($output) {
		if(strlen($this->path)) {
			if($this->cleanLogFile && !$this->logFileIsCleaned) {
				file_put_contents($this->path, $output);
				$this->logFileIsCleaned = true;
			} else {
				file_put_contents($this->path, file_get_contents($this->path).$output);
			}
		} else {
			echo $output;
		}
	}
	
	private function getTraceIfNeeded() {
		if($this->showPlace) {
			$trace = debug_backtrace(false, 2);
			$traceInfo = preg_replace('/.*\/([^\/]*\.php).*$/', '$1', $trace[1]["file"]);
			return ' ['.$traceInfo.'|'.$trace[1]["line"].']';
		} else {
			return '';
		}
	}
	
	private function prepareArray($array){

		$unit = $this->showUnit ? 'bytes' : '';
		
		$output = gettype($array).' ('.count($array).')';

		foreach($array as $key => $item) {
			$isTree = false;
			if(is_array($item) || is_object($item)) {
				$isTree = true;
				$item = $this->prepareArray($item);
			}

			$valueType = '';
			$valueMemUsage = '';
			$keyClass = ($isTree) ? 'key' : 'static-key';
			if(!$isTree) {
				
				if($this->showVarType) {
					$valueType = gettype($item);
				}

				if($this->showVarMemUsage) {
					$valueMemUsage = ' '.(strlen($item)*8).$unit;
				}
			}
			$extraInfo = $valueType.$valueMemUsage;
			$output .= $this->getProcessTemplate('array_item', Array(
				'arrayMode' => $this->arrayMode,
				'valueType' => $valueType == 'string' && strlen($item) > 200 ? 2 : 1,
				'keyClass' => $keyClass,
				'key' => $key,
				'item' => $item,
				'extraInfo' => $extraInfo,
			));
		}

		return $output;
	}
	
	private function dumpObject($object) {
	
		if(!is_object($object) && !is_array($object)) {
			$this->throwError('dump_object_invalid_param');
		}
		
		ob_start();
		var_dump($object);
		$object = ob_get_contents();
		ob_end_clean();
		
		if($this->type == 'html') {
			$object = $this->getProcessTemplate('object', Array('object' => $object));
		}
		
		return $object;
	}
	
	private function includeMediaIfNeeded(&$styles, &$scripts) {
		if(!defined("PHP_TELLER_MEDIA_INCLUDED")) {
			$scriptsFile = $this->getClassDestination().'/scripts/script.min.js';
			if (!file_exists($scriptsFile)) {
				$this->throwError('no_js');
			}
			$stylesFile = $this->getClassDestination().'/styles/style.min.css';
			if (!file_exists($stylesFile)) {
				$this->throwError('no_css');
			}
			$styles = $this->getProcessTemplate('styles', Array(
				'styles' => file_get_contents($stylesFile)
			), false);
			$scripts = $this->getProcessTemplate('scripts', Array(
				'scripts' => file_get_contents($scriptsFile),
			), false);
			define("PHP_TELLER_MEDIA_INCLUDED", true);
		}
	}
	
	private function getProcessTemplate($templateName, $data, $removeEmpty = true) {

		$templatePath = $this->getClassDestination().'/templates/'.$templateName.'.tpl';
		
		if (!file_exists($templatePath)) {
			$this->throwError('no_template', Array('templatePath' => $templatePath));
		}
		
		$template = file_get_contents($templatePath);

		if(is_array($data) && count($data)) {
			$replaces = Array();
			foreach($data as $varName => $value) {
				$placeholder = '{'.$varName.'}';
				
				$replaces[$placeholder] = $value;
				
				if(!strlen($value) && $removeEmpty) {
					$template = preg_replace('/\(\(.*'.$placeholder.'.*\)\)/', '', $template);
				}
			}
			if(count($replaces)) {
				$template = str_replace(array_keys($replaces), array_values($replaces), $template);
			}
		}
		
		if($removeEmpty)
			$template = str_replace(Array('((', '))'), '', $template);
		
		return $template;
	}
   
	public function memUsage($comment = '') {
		
		$traceInfo = $this->getTraceIfNeeded();

		if(strlen($comment))
			$comment = ' // '.$comment;
			
		$unit = $this->showUnit ? 'bytes' : '';
		$time = $this->showTime ? ' '.date('d.m.y H:i:s') : '';
		
		if(!$this->baseMemUsageValue) {
			$this->baseMemUsageValue = memory_get_usage();
			$this->lastMemUsageValue = 0;
			$output = '(mem) #0'.$time.$traceInfo.': 0'.$unit.$comment.$this->newLine;
		} else {
			$this->memUsageIndex = intval($this->memUsageIndex) + 1;
			$newMemUsageValue = memory_get_usage() - $this->baseMemUsageValue;
			$memUsageDiff = $newMemUsageValue-$this->lastMemUsageValue;
			if($memUsageDiff > 0)
				$memUsageDiff = '+'.$memUsageDiff;
			$output = '(mem) #'.$this->memUsageIndex.$time.$traceInfo.': '.$newMemUsageValue.$unit.' ('.$memUsageDiff.$unit.')'.$comment.$this->newLine;
			$this->lastMemUsageValue = $newMemUsageValue;
		}

		$this->output($output);
	}
	
	public function timeUsage($comment = '') {
		
		$traceInfo = $this->getTraceIfNeeded();
		
		if(strlen($comment))
			$comment = ' // '.$comment;
			
		$unit = $this->showUnit ? 'sec' : '';
		$time = $this->showTime ? ' '.date('d.m.y H:i:s') : '';
			
		if(!$this->baseTimeUsageValue) {
			$this->baseTimeUsageValue = microtime(true);
			$this->lastTimeUsageValue = 0;
			$output = '(time) #0'.$time.$traceInfo.': 0'.$unit.$comment.$this->newLine;
		} else {
			$this->timeUsageIndex = intval($this->timeUsageIndex) + 1;
			$newTimeUsageValue = microtime(true) - $this->baseTimeUsageValue;
			$timeUsageDiff = $newTimeUsageValue-$this->lastTimeUsageValue;
			if($timeUsageDiff > 0)
				$timeUsageDiff = '+'.number_format($timeUsageDiff, $this->timePrecision);
			$output = '(time) #'.$this->timeUsageIndex.$time.$traceInfo.': '.number_format($newTimeUsageValue, $this->timePrecision).$unit.' ('.$timeUsageDiff.$unit.')'.$comment.$this->newLine;
			$this->lastTimeUsageValue = $newTimeUsageValue;
		}
		
		$this->output($output);
	}
	
	public function log() {
	
		$styles = $scripts = '';
		
		$traceInfo = $this->getTraceIfNeeded();
		
		$time = $this->showTime ? ' '.date('d.m.y H:i:s') : '';
		
		$this->dumpIndex = intval($this->dumpIndex) + 1;
		
		$output = '(log) #'.$this->dumpIndex.$time.$traceInfo.': ';
		
		$dumpItems = func_get_args();
		$itemsCount = count($dumpItems);
		
		foreach($dumpItems as $key => $item) {
			$noSeparator = false;
			if(is_array($item) || is_object($item)) {
				$noSeparator = true;
				if($this->type == 'html') {
					$this->includeMediaIfNeeded($styles, $scripts);

					$item = $this->prepareArray($item);
					$item = $this->getProcessTemplate('container', Array('item' => $item));
				} else {
					$item = $this->dumpObject($item);
				}
			} 
			
			$separator = !$noSeparator && $key+1 < $itemsCount ? ' | ' : '';
			
			$output .= $item.$separator;
		}
		
		$this->output($styles.$output.$this->newLine.$scripts);
		
	}
}
?>