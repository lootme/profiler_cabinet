(function(container, keys, largeTextes, arrows, arrowUp, arrowDn, blocks, thisBlockHasArrows, activeBlocks){
	function scrollTo(element, to, duration) { // Function borrowed from here https://codepen.io/sturobson/
			if (duration <= 0) return;
			var difference = to - element.scrollTop,
				perTick = difference / duration * 2;

		setTimeout(function() {
			element.scrollTop = element.scrollTop + perTick;
			scrollTo(element, to, duration - 2);
		}, 10);
	}
	function getOffsetTop(elem) {
		var box = elem.getBoundingClientRect(),
			body = document.body,
			docEl = document.documentElement,
			scrollTop = window.pageYOffset || docEl.scrollTop || body.scrollTop,
			clientTop = docEl.clientTop || body.clientTop || 0;
			offsetTop  = box.top + scrollTop - clientTop;

		return Math.round(offsetTop);
	}
	if(container !== null) {
		for (i = 0; i < container.length; i++) {
			keys = container[i].querySelectorAll(".key");
			if(keys !== null) {
				for (j = 0; j < keys.length; j++) {
					keys[j].addEventListener('click', function() {
						this.parentNode.classList.toggle('active');
					});
				}
			}
			
			largeTextes = container[i].querySelectorAll(".v2");
			if(largeTextes !== null) {
				for (j = 0; j < largeTextes.length; j++) {
					largeTextes[j].addEventListener('click', function() {
						this.classList.toggle('opened');
					});
				}
			}
			
			blocks = container[i].querySelectorAll(".b");
			if(blocks.length) {
				for (j = 0; j < blocks.length; j++) {
					blocks[j].addEventListener("mousemove", function(event) {
						event.stopPropagation();
						var _this = this;
							arrows = document.querySelectorAll(".php-teller-dump-container .arrows");
						if(_this.clientHeight <= 300) {
							return;
						}
						if(this.classList.contains("active") && event.offsetX < 20) {
							activeBlocks = document.querySelectorAll(".php-teller-dump-container .b.active");
							thisBlockHasArrows = false;
							if(arrows.length) {
								for (k = 0; k < arrows.length; k++) {
									if(arrows[k].parentNode == this) {
										thisBlockHasArrows = true;
										continue;
									} else {
										arrows[k].parentNode.removeChild(arrows[k]);
									}
								}
							}
							if(!thisBlockHasArrows) {
								arrows = document.createElement('div');
								arrowUp = document.createElement('div');
								arrowDn = document.createElement('div');
								arrows.classList.add('arrows');
								arrows.style.top = event.offsetY + 'px';
								arrowUp.classList.add('arrows-up');
								arrowUp.innerHTML = '&uarr;';
								arrowUp.addEventListener("click", function(event) {
									scrollTo(document.body, getOffsetTop(_this), 100);
								});
								arrowDn.classList.add('arrows-dn');
								arrowDn.innerHTML = '&darr;';
								arrowDn.addEventListener("click", function(event) {
									scrollTo(document.body, getOffsetTop(_this) + _this.clientHeight - 200, 50);
								});
								arrows.insertBefore(arrowDn, arrows.firstChild);
								arrows.insertBefore(arrowUp, arrows.firstChild);
								this.insertBefore(arrows, this.firstChild);
							}
						} else if(arrows.length) {
							for (k = 0; k < arrows.length; k++) {
								arrows[k].parentNode.removeChild(arrows[k]);
							}
						}
					});
				}
			}
			container[i].classList.add('r'); // ready
		}
	}
}(document.querySelectorAll('.php-teller-dump-container')));